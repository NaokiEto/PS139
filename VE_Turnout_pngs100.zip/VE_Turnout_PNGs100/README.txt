To calculate V/E for each candidate, I divided the number of votes that candidate had by the number of registered voters

To calculate voter turnout, I divided (valid + invalid votes) by the number of registered voters

these graphs are only for polling stations that had more than 100 (valid + invalid) votes
